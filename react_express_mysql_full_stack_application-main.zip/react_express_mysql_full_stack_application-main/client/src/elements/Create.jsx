import React, { useState } from 'react'
import axios from 'axios'
import {Link, useNavigate} from 'react-router-dom'

function Create() {
    const [values, setValues] = useState({
        name: '',
        email: '',
        age: '',
        gender: ''
    })

    const navigate = useNavigate()

    function handleSubmit(e){
        e.preventDefault()

        axios.post('/add_user', values)
        .then((res)=>{
            
            navigate('/')
            console.log(res)
        })
        .catch((err)=>console.log(err))
    }
  return (
    <div className='container-fluid vh-100 vw-100 bg-dark text-light'>
        <div className='row'>
            <h3><u>Add Student</u></h3>
            <div className='d-flex justify-content-end'>
                <Link to='/' class='btn btn-success'>Home</Link>
            </div>
            <form onSubmit={handleSubmit} className="" style={{border: "2px solid white", width:"60%",margin:"auto", fontSize:"20px", padding:"25px" }}>
                <div className='form-group my-3'>
                    <label htmlFor='name'>Name</label>
                    <input className="form-control" type='text' name='name' required onChange={(e)=> setValues({...values, name: e.target.value})} />
                </div><br />
                <div className='form-group my-3'>
                    <label htmlFor='email'>Email</label>
                    <input className="form-control" type='email' name='email' required onChange={(e)=> setValues({...values, email: e.target.value})} />
                </div><br />
                <div className='form-group my-3'>
                    <label htmlFor='gender'>Gender</label>
                    <input className="form-control" type='text' name='gender' required onChange={(e)=> setValues({...values, gender: e.target.value})} />
                </div><br />
                <div className='form-group my-3'>
                    <label htmlFor='age'>Age</label>
                    <input className="form-control" type='number' name='age' required onChange={(e)=> setValues({...values, age: e.target.value})} />
                </div><br />
                <div className='form-group my-2 text-center'>
                    <button type='submit'  className='btn btn-success text-center'>Save</button>
                </div>
            </form>
        </div>
    </div>
  )
}

export default Create